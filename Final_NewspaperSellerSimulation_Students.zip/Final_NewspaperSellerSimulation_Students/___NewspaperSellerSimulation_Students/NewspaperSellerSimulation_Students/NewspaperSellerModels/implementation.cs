﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace NewspaperSellerModels
{
    public class implementation
    {
        public void Read_file(string path, ref SimulationSystem s)
        {


            FileStream fs = new FileStream(path, FileMode.Open, FileAccess.Read);
            StreamReader sr = new StreamReader(fs);

            string line = null;
            s = new SimulationSystem();
            while (sr.Peek() != -1)
            {
                line = sr.ReadLine();

                if (line == "")
                {
                    continue;
                }

                line = line.ToLower();
                if (line.Contains("numofnewspapers"))
                {
                    line = sr.ReadLine();
                    s.NumOfNewspapers = int.Parse(line);
                    Console.WriteLine("NumOfNewspapers: " + s.NumOfNewspapers);

                }
                else if (line.Contains("numofrecords"))
                {
                    line = sr.ReadLine();
                    s.NumOfRecords = int.Parse(line);
                    Console.WriteLine("NumOfRecords: " + s.NumOfRecords);

                }
                else if (line.Contains("purchaseprice"))
                {
                    line = sr.ReadLine();
                    s.PurchasePrice = decimal.Parse(line);
                    Console.WriteLine("PurchasePrice: " + s.PurchasePrice);
                }
                else if (line.Contains("scrapprice"))
                {
                    line = sr.ReadLine();
                    s.ScrapPrice = decimal.Parse(line);
                    Console.WriteLine("ScrapPrice: " + s.ScrapPrice);

                }
                else if (line.Contains("sellingprice"))
                {
                    line = sr.ReadLine();
                    s.SellingPrice = decimal.Parse(line);
                    Console.WriteLine("SellingPrice: " + s.SellingPrice);

                }

                else if (line.Contains("daytypedistributions"))
                {
                    line = sr.ReadLine();
                    string[] distrubution = line.Split(',');
                    s.DayTypeDistributions.Add(new DayTypeDistribution());

                    s.DayTypeDistributions[0].DayType = (Enums.DayType)0;
                    s.DayTypeDistributions[0].Probability = decimal.Parse(distrubution[0]);

                    s.DayTypeDistributions.Add(new DayTypeDistribution());
                    s.DayTypeDistributions[1].DayType = (Enums.DayType)1;
                    s.DayTypeDistributions[1].Probability = decimal.Parse(distrubution[1]);
                    s.DayTypeDistributions.Add(new DayTypeDistribution());
                    s.DayTypeDistributions[2].DayType = (Enums.DayType)2;
                    s.DayTypeDistributions[2].Probability = decimal.Parse(distrubution[2]);
                    Console.WriteLine("DayTypeDistribution: " + s.DayTypeDistributions[0].DayType + "   " + s.DayTypeDistributions[0].Probability + "   " + s.DayTypeDistributions[1].DayType + "   " + s.DayTypeDistributions[1].Probability + "   " + s.DayTypeDistributions[2].DayType + "   " + s.DayTypeDistributions[2].Probability + "   ");

                }
                else
                {

                    for (int j = 0; ; j++)
                    {


                        line = sr.ReadLine();

                        if (!(line == "") && !(line == null))
                        {
                            s.DemandDistributions.Add(new DemandDistribution());
                            string[] distrubution = line.Split(',');
                            s.DemandDistributions[j].Demand = int.Parse(distrubution[0]);
                            s.DemandDistributions[j].DayTypeDistributions.Add(new DayTypeDistribution());
                            s.DemandDistributions[j].DayTypeDistributions[0].DayType = (Enums.DayType)0;
                            s.DemandDistributions[j].DayTypeDistributions[0].Probability = decimal.Parse(distrubution[1]);
                            s.DemandDistributions[j].DayTypeDistributions.Add(new DayTypeDistribution());
                            s.DemandDistributions[j].DayTypeDistributions[1].DayType = (Enums.DayType)1;
                            s.DemandDistributions[j].DayTypeDistributions[1].Probability = decimal.Parse(distrubution[2]);
                            s.DemandDistributions[j].DayTypeDistributions.Add(new DayTypeDistribution());
                            s.DemandDistributions[j].DayTypeDistributions[2].DayType = (Enums.DayType)2;
                            s.DemandDistributions[j].DayTypeDistributions[2].Probability = decimal.Parse(distrubution[3]);
                            Console.WriteLine("DemandDistributions: " + "\n" + s.DemandDistributions[j].Demand + "   " + s.DemandDistributions[j].DayTypeDistributions[0].DayType + "   " + s.DemandDistributions[j].DayTypeDistributions[0].Probability + "   " + s.DemandDistributions[j].DayTypeDistributions[1].DayType + "   " + s.DemandDistributions[j].DayTypeDistributions[1].Probability + "   " + s.DemandDistributions[j].DayTypeDistributions[2].DayType + "   " + s.DemandDistributions[j].DayTypeDistributions[2].Probability + "   ");


                        }
                        else { break; }
                    }




                }

            }
        }
        public static List<DayTypeDistribution> Set_Day_Distribution(List<DayTypeDistribution> day_type_dist)
        {

            for (int i = 0; i < 3; i++)
            {
                if (i == 0)
                {
                    day_type_dist[i].CummProbability = day_type_dist[i].Probability;
                    day_type_dist[i].MinRange = 1;
                }
                else
                {
                    day_type_dist[i].CummProbability = day_type_dist[i].Probability + day_type_dist[i - 1].CummProbability;
                    day_type_dist[i].MinRange = day_type_dist[i - 1].MaxRange + 1;
                }
                day_type_dist[i].MaxRange = (int)(day_type_dist[i].CummProbability * 100);

            }
            return day_type_dist;
        }

        public static void set_demand_dist(List<DemandDistribution> DemandDistributions)
        {
            for (int i = 0; i < DemandDistributions.Count(); i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    if (i == 0)
                    {
                        DemandDistributions[i].DayTypeDistributions[j].MinRange = 1;
                        DemandDistributions[i].DayTypeDistributions[j].CummProbability = DemandDistributions[i].DayTypeDistributions[j].Probability;
                        //Console.WriteLine("value of probability=" + DemandDistributions[i].DayTypeDistributions[j].Probability);

                        DemandDistributions[i].DayTypeDistributions[j].MaxRange = (int)(DemandDistributions[i].DayTypeDistributions[j].CummProbability * 100);
                        
                        Console.WriteLine(" if day type=" + j);
                        Console.WriteLine("value of Demand=" + DemandDistributions[i].Demand);

                        Console.WriteLine("value of probability=" + DemandDistributions[i].DayTypeDistributions[j].Probability);
                        Console.WriteLine("value of cumm prob=" + DemandDistributions[i].DayTypeDistributions[j].CummProbability);
                        Console.WriteLine("value of min range=" + DemandDistributions[i].DayTypeDistributions[j].MinRange);
                        Console.WriteLine("value of max range=" + DemandDistributions[i].DayTypeDistributions[j].MaxRange);
                        Console.WriteLine("*********************");
                    }
                    else
                    {


                        if (DemandDistributions[i - 1].DayTypeDistributions[j].MaxRange == 100) break;
                        DemandDistributions[i].DayTypeDistributions[j].MinRange = DemandDistributions[i - 1].DayTypeDistributions[j].MaxRange + 1;

                        DemandDistributions[i].DayTypeDistributions[j].CummProbability =
                            DemandDistributions[i - 1].DayTypeDistributions[j].CummProbability + DemandDistributions[i].DayTypeDistributions[j].Probability;

                        DemandDistributions[i].DayTypeDistributions[j].MaxRange = (int)(DemandDistributions[i].DayTypeDistributions[j].CummProbability * 100);



                        Console.WriteLine(" if day type=" + j);
                        Console.WriteLine("value of Demand=" + DemandDistributions[i].Demand);

                        Console.WriteLine("value of probability=" + DemandDistributions[i].DayTypeDistributions[j].Probability);
                        Console.WriteLine("value of cumm prob=" + DemandDistributions[i].DayTypeDistributions[j].CummProbability);
                        Console.WriteLine("value of min range=" + DemandDistributions[i].DayTypeDistributions[j].MinRange);
                        Console.WriteLine("value of max range=" + DemandDistributions[i].DayTypeDistributions[j].MaxRange);
                        Console.WriteLine("*********************");
                    }
                }
            }
        }

        public static Random rand = new Random();
        public static int randomNum()
        {
            return rand.Next(1, 100);
        }
        public static void set_NewsDayType(List<DayTypeDistribution> day_type_dis, SimulationCase sim_table_row)
        {

            sim_table_row.RandomNewsDayType = randomNum();
            foreach (var i in day_type_dis)
            {
                if (sim_table_row.RandomNewsDayType <= i.MaxRange)
                {
                    sim_table_row.NewsDayType = i.DayType;
                    break;
                }
            }
        }
        public void set_Demand(List<DemandDistribution> DemandDistributions, SimulationCase sim_table_row)
        {

            sim_table_row.RandomDemand = randomNum();
            int v = sim_table_row.RandomDemand;
            int dayType = 0;
            if (sim_table_row.NewsDayType == Enums.DayType.Good)
            { dayType = 0; }
            if (sim_table_row.NewsDayType == Enums.DayType.Fair)
            { dayType = 1; }
            if (sim_table_row.NewsDayType == Enums.DayType.Poor)
            { dayType = 2; }

            /*Console.WriteLine("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
            Console.WriteLine("random demand=" + sim_table_row.RandomDemand);
            Console.WriteLine("daytype="+dayType);
            Console.WriteLine("sim_table_row.NewsDayType=" + sim_table_row.NewsDayType);
            Console.WriteLine("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");*/
            
            foreach (var i in DemandDistributions)
            {
                
                if (v>= i.DayTypeDistributions[dayType].MinRange && v <= i.DayTypeDistributions[dayType].MaxRange)
                {
                    
                    sim_table_row.Demand = i.Demand;


                    Console.WriteLine("**************");
                    Console.WriteLine("sim_table_row.RandomDemand=" +v );
                    Console.WriteLine("day type=" + dayType);
                    Console.WriteLine("sim_table_row.NewsDayType=" + sim_table_row.NewsDayType);
                    Console.WriteLine("sim_table_row.NewsDayType=" + i.DayTypeDistributions[dayType].DayType);
                    Console.WriteLine("  sim_table_row.Demand = i.Demand  = " + sim_table_row.Demand);
                    Console.WriteLine("i.DayTypeDistributions[dayType].MinRange=" + i.DayTypeDistributions[dayType].MinRange);
                    Console.WriteLine("i.DayTypeDistributions[dayType].maxRange=" + i.DayTypeDistributions[dayType].MaxRange);
                    Console.WriteLine("////////////////////////////////////////////////////");
                    

                    break;
                }
            }
        }

        public void fill_sim_table(SimulationSystem sim_sys)
        {
            for (int i = 0; i < sim_sys.NumOfRecords; i++)
            {
                SimulationCase sim_table_row = new SimulationCase();
                sim_table_row.DayNo = i;
                set_NewsDayType(sim_sys.DayTypeDistributions, sim_table_row);
                set_Demand(sim_sys.DemandDistributions, sim_table_row);
                sim_sys.SimulationTable.Add(sim_table_row);
            }


            for (int i = 0; i < sim_sys.NumOfRecords; i++)
            {

                sim_sys.SimulationTable[i].DailyCost = sim_sys.PurchasePrice * sim_sys.NumOfNewspapers;
                sim_sys.SimulationTable[i].SalesProfit = 
                    sim_sys.SellingPrice * Math.Min(sim_sys.SimulationTable[i].Demand, sim_sys.NumOfNewspapers);
                sim_sys.SimulationTable[i].ScrapProfit = 0;
                sim_sys.SimulationTable[i].LostProfit =0;
                if (sim_sys.SimulationTable[i].Demand > sim_sys.NumOfNewspapers)
                {
                    sim_sys.UnitProfit=(decimal)(0.5-0.33);
                    Console.WriteLine("sim_sys.NumOfNewspapers=" + sim_sys.NumOfNewspapers);
                    Console.WriteLine("unitprofit=" + sim_sys.UnitProfit);
                    sim_sys.SimulationTable[i].LostProfit = 
                        (sim_sys.SimulationTable[i].Demand - sim_sys.NumOfNewspapers) * sim_sys.UnitProfit;
                    sim_sys.SimulationTable[i].DailyNetProfit =
                        sim_sys.SimulationTable[i].SalesProfit - sim_sys.SimulationTable[i].DailyCost - sim_sys.SimulationTable[i].LostProfit + sim_sys.SimulationTable[i].ScrapProfit;

                }
                else
                {
                    sim_sys.SimulationTable[i].ScrapProfit =
                        (sim_sys.NumOfNewspapers - sim_sys.SimulationTable[i].Demand) * sim_sys.ScrapPrice;
                    sim_sys.SimulationTable[i].DailyNetProfit = 
                        sim_sys.SimulationTable[i].SalesProfit - sim_sys.SimulationTable[i].DailyCost - sim_sys.SimulationTable[i].LostProfit + sim_sys.SimulationTable[i].ScrapProfit;
                }
            }

            //performance
            for (int i = 0; i < sim_sys.NumOfRecords; i++)
            {
                sim_sys.PerformanceMeasures.TotalCost += sim_sys.SimulationTable[i].DailyCost;
                sim_sys.PerformanceMeasures.TotalSalesProfit += sim_sys.SimulationTable[i].SalesProfit;
                sim_sys.PerformanceMeasures.TotalNetProfit += sim_sys.SimulationTable[i].DailyNetProfit;
                sim_sys.PerformanceMeasures.TotalLostProfit += sim_sys.SimulationTable[i].LostProfit;
                sim_sys.PerformanceMeasures.TotalScrapProfit += sim_sys.SimulationTable[i].ScrapProfit;

                if (sim_sys.SimulationTable[i].LostProfit > sim_sys.SimulationTable[i].ScrapProfit)
                {
                    sim_sys.PerformanceMeasures.DaysWithMoreDemand++;
                }

                else if (sim_sys.SimulationTable[i].LostProfit < sim_sys.SimulationTable[i].ScrapProfit)
                {
                    sim_sys.PerformanceMeasures.DaysWithUnsoldPapers++;
                }
            }

        }
    }
}
