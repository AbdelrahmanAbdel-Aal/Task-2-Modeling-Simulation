NumOfNewspapers (single lines) 
// value of num of newspapers to simulate on  ===> example: 70

NumOfRecords (single lines) 
// stopping condition when reaching record number ===> example: 20

PurchasePrice (single lines) 
// the price by which the seller buys ===> example: 0.33

ScrapPrice (single lines) 
// the price of newspapers that are not sold at the end of the day ===> 0.05

SellingPrice (single lines) 
// the price by which the seller sells ===> example: 0.50

DayTypeDistributions (single lines) 
// goodProbability,  fairProbability,  poorProbability ===> example: 0.35, 0.45, 0.20

DemandDistributions (multiple lines)
// demand, goodProbability,  fairProbability,  poorProbability ===> example: 40, 0.03, 0.10, 0.44