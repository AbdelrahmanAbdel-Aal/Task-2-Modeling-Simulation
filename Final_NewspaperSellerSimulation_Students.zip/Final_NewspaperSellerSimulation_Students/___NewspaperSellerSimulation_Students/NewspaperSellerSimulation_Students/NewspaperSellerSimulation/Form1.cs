﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using NewspaperSellerModels;
using NewspaperSellerTesting;
using System.IO;



namespace NewspaperSellerSimulation
{
    public partial class Form1 : Form
    {
        public SimulationSystem system;
        public SimulationCase sim_case;
        
        public int NumOfTestCase=0;
        public Form1(SimulationSystem system, SimulationCase sim_case) 
        {
            this.system = system;
            this.sim_case = sim_case;
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

            
        }
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            radioTestCase1.Checked = true;
            radioTestCase2.Checked = false;
            radioTestCase3.Checked = false;
            NumOfTestCase = 1;
            Data_Entry();
        }

        private void radioTestCase2_CheckedChanged(object sender, EventArgs e)
        {
            radioTestCase2.Checked = true;
            radioTestCase1.Checked = false;
            radioTestCase3.Checked = false;
            NumOfTestCase = 2;
            Data_Entry();
        }

        private void radioTestCase3_CheckedChanged(object sender, EventArgs e)
        {
            radioTestCase3.Checked = true;
            radioTestCase1.Checked = false;
            radioTestCase2.Checked = false;
            NumOfTestCase = 3;
            Data_Entry();
        }
        public void Data_Entry() 
        { 
            
            string path = "TestCase" + NumOfTestCase.ToString() + ".txt";

            implementation implementation = new implementation();
            implementation.Read_file(path, ref system);
            implementation.Set_Day_Distribution(system.DayTypeDistributions);
            implementation.set_demand_dist(system.DemandDistributions);
            implementation.set_NewsDayType(system.DayTypeDistributions, sim_case );
            implementation.set_Demand(system.DemandDistributions, sim_case);
            implementation.fill_sim_table(system);

            // Data Entry in Table
            DataTable table1 = new DataTable();
            table1.Columns.Add("Day Number", typeof(int));
            table1.Columns.Add("Random News Day Type", typeof(int));
            table1.Columns.Add("News Day Type", typeof(string));
            table1.Columns.Add("Random Demand", typeof(int));
            table1.Columns.Add("Demand", typeof(int));
            table1.Columns.Add("Sales Profit", typeof(float));
            table1.Columns.Add("Lost Profit", typeof(float));
            table1.Columns.Add("Scrap Profit", typeof(float));
            table1.Columns.Add("Daily Net Profit", typeof(float));
            dataGridView1.DataSource = table1;

            for (int f = 0; f < system.NumOfRecords; f++)
            {
                table1.Rows.Add((system.SimulationTable[f].DayNo+1), system.SimulationTable[f].RandomNewsDayType,
                system.SimulationTable[f].NewsDayType, system.SimulationTable[f].RandomDemand,
                system.SimulationTable[f].Demand, system.SimulationTable[f].SalesProfit,
                system.SimulationTable[f].LostProfit, system.SimulationTable[f].ScrapProfit,
                system.SimulationTable[f].DailyNetProfit);
            }

            // Data Entry in Box
            textTotalSalesRevenue.Text = system.PerformanceMeasures.TotalSalesProfit.ToString()+ "$";
            textTotalCostofNewspapers.Text = system.PerformanceMeasures.TotalCost.ToString() + "$";
            textTotalLostProfitfromExcessDemand.Text = system.PerformanceMeasures.TotalLostProfit.ToString() + "$";
            textTotalSalvagefromsaleofScrappapers.Text = system.PerformanceMeasures.TotalScrapProfit.ToString() + "$";
            textNetProfit.Text = system.PerformanceMeasures.TotalNetProfit.ToString();
            textNumberofdayshavingexcessdemand.Text = system.PerformanceMeasures.DaysWithMoreDemand.ToString();
            textNumberofDaysHavingUnsoldPapers.Text = system.PerformanceMeasures.DaysWithUnsoldPapers.ToString();



            string testingResult = "";
            if (NumOfTestCase == 1)
                testingResult = TestingManager.Test(system, Constants.FileNames.TestCase1);
            else if (NumOfTestCase == 2)
                testingResult = TestingManager.Test(system, Constants.FileNames.TestCase2);
            else if (NumOfTestCase == 3)
                testingResult = TestingManager.Test(system, Constants.FileNames.TestCase3);

            MessageBox.Show(testingResult);
        }

    }
}
